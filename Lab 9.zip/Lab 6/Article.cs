﻿using System;

namespace Progect_5
{
    [Serializable]
    public class Article : IComparable<Article>
    {
        public string Author { get; set; }
        public int Pages { get; set; }
        public string Title { get; set; }
        public string Topic { get; set; }
        public DateTime Date { get; set; }
        public string Place { get; set; }
        public string Language { get; set; }
        public int Year { get; set; }

        public int CompareTo(Article other)
        {
            return Year.CompareTo(other.Year);
        }

        public override string ToString()
        {
            return
                $"Автор: {Author}\n" +
                $"Кількість сторінок: {Pages}\n" +
                $"Назва: {Title}\n" +
                $"Тема: {Topic}\n" +
                $"Дата: {Date:yyyy-MM-dd}\n" +
                $"Місце: {Place}\n" +
                $"Мова: {Language}\n" +
                $"Рік: {Year}\n";
        }
    }
}
