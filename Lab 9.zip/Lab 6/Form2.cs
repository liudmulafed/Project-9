﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Progect_5
{
    public partial class Form2 : Form
    {
        List<Article> articles;

        public Form2(List<Article> articles)
        {
            InitializeComponent();
            this.articles = articles.OrderBy(a => a.Year).ToList();
            SetupGrid();
            LoadData();
        }
        private void SetupGrid()
        {
            dataGridView1.ColumnCount = 8;
            dataGridView1.Columns[0].Name = "Автор";
            dataGridView1.Columns[1].Name = "Назва";
            dataGridView1.Columns[2].Name = "Сторінки";
            dataGridView1.Columns[3].Name = "Тема";
            dataGridView1.Columns[4].Name = "Дата";
            dataGridView1.Columns[5].Name = "Місце";
            dataGridView1.Columns[6].Name = "Мова";
            dataGridView1.Columns[7].Name = "Рік";

            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ReadOnly = true;
        }
        private void LoadData()
        {
            foreach (var a in articles)
            {
                dataGridView1.Rows.Add(
                    a.Author,
                    a.Title,
                    a.Pages,
                    a.Topic,
                    a.Date.ToString("yyyy-MM-dd"),
                    a.Place,
                    a.Language,
                    a.Year
                );
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
