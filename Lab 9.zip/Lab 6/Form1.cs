﻿using Lab_6;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;

namespace Progect_5
{
    public partial class Form1 : Form
    {
        List<Article> articles = new List<Article>();
        Random rnd = new Random();


        public Form1()
        {
            InitializeComponent();

            comboBoxOptions.Items.AddRange(new string[]
            {
                "Наукова",
                "Технічна",
                "Публіцистична"
            });

            comboBoxOptions.SelectedIndex = 0;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Article a = new Article
                {
                    Author = textBoxAuthor.Text,
                    Pages = int.Parse(textBoxPages.Text),
                    Title = textBoxTitle.Text,
                    Topic = textBoxTopic.Text,
                    Date = DateTime.Parse(textBoxDate.Text),
                    Place = textBoxPlace.Text,
                    Language = textBoxLanguage.Text,
                    Year = int.Parse(textBoxYear.Text)
                };

                articles.Add(a);
                File.WriteAllText("article.txt", a.ToString());

                Article second = new Article
                {
                    Author = a.Author,
                    Pages = a.Pages,
                    Title = a.Title,
                    Topic = a.Topic,
                    Date = a.Date,
                    Place = a.Place,
                    Language = a.Language,
                    Year = a.Year
                };
                BinaryFormatter formatter = new BinaryFormatter();

                using (FileStream fs = new FileStream("article.dat", FileMode.Create))
                {
                    formatter.Serialize(fs, second);
                }

                MessageBox.Show(
                    "Стаття додана!");

                foreach (var tb in Controls.OfType<TextBox>())
                    tb.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка введення: " + ex.Message);
            }
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            if (articles.Count == 0)
            {
                MessageBox.Show("Список порожній.");
                return;
            }

            Form2 form = new Form2(articles);
            form.Show();
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            foreach (var tb in Controls.OfType<TextBox>())
                tb.Clear();

            comboBoxOptions.SelectedIndex = 0;
        }

        private void buttonColor_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.FromArgb(
                rnd.Next(256), rnd.Next(256), rnd.Next(256)
            );
        }

        private void buttonComboApply_Click(object sender, EventArgs e)
        {
            if (comboBoxOptions.SelectedItem != null)
                textBoxComboResult.Text = comboBoxOptions.SelectedItem.ToString();
        }
    }
}
